﻿Public Partial Class AfterCustomerLogin1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label1.Text = Session("uname")
        Label2.Text = Session("vsid")
    End Sub

    Private Sub AfterCustomerLogin1_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Session("uname") = Label1.Text
    End Sub

  
    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button2.Click
        Session.Clear()
        Server.Transfer("Default.aspx")
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button3.Click
        Session("SearchValue") = TextBox1.Text
        Server.Transfer("SearchForProduct.aspx")
    End Sub
End Class