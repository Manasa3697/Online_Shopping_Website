﻿Public Partial Class ALTERQTYINCART
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim vc As String
            vc = ""

            Label6.Text = Request.QueryString("vcartid")
            Label3.Text = Request.QueryString("vpid")
            Label4.Text = Request.QueryString("vpname")
            TextBox1.Text = Request.QueryString("vqty")

            Dim con As OleDb.OleDbConnection
            Dim s As String
            con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")

            Dim dset As New DataSet()
            Dim dtab As New DataTable()
            Dim I As Integer

            I = 0
            s = "select *  from productMaster where Productid='" + Label3.Text + "'"

            Dim cmd As New Data.OleDb.OleDbDataAdapter(s, con)

            con.Open()
            cmd.Fill(dset, "xyz")

            For Each row In dset.Tables(0).Rows
                Label4.Text = row("ProductName")
                Label7.Text = row("ProductPrice")
                If row("ProductStatus") = "Y" Then
                    Label5.Text = row("CurrStock")
                Else
                    Label5.Text = 0
                End If

            Next
            cmd.Dispose()
            dset.Clear()
            con.Close()
        End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        Dim con As OleDb.OleDbConnection
        Dim cmd As OleDb.OleDbCommand
        con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")
        cmd = New OleDb.OleDbCommand()

        cmd.CommandText = "UPDATE CART SET QUANTITY=" + TextBox1.Text + " WHERE CARTID='" + Label6.Text + "' AND PRODUCTID='" + Label3.Text + "'"
        cmd.Connection = con
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
        Dim vform As String
        vform = Request.QueryString("vform").ToString
        If vform = "1" Then
            Server.Transfer("finishcart.ASPX")
        Else
            Server.Transfer("showcart.ASPX")
        End If

    End Sub
End Class