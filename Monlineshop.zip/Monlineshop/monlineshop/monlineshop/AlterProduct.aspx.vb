﻿Public Partial Class AlterProduct
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            TextBox1.Text = Request.QueryString("vpid")
            Dim con As OleDb.OleDbConnection
            Dim s As String
            con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")

            Dim dset As New DataSet()
            Dim dtab As New DataTable()
            Dim I As Integer


            I = 0
            s = "select categoryid  from categorymaster"

            Dim cmd As New Data.OleDb.OleDbDataAdapter(s, con)

            con.Open()
            cmd.Fill(dset, "xyz")

            For Each row In dset.Tables(0).Rows
                DropDownList1.Items.Add(row("categoryid"))
            Next
            cmd.Dispose()
            dset.Clear()
            con.Close()

            I = 0
            s = "select *  from Productmaster where productid='" + TextBox1.Text + "'"

            Dim cmd1 As New Data.OleDb.OleDbDataAdapter(s, con)

            con.Open()
            cmd1.Fill(dset, "xyz")

            For Each row In dset.Tables(0).Rows
                TextBox2.Text = row("ProductName")
                TextBox3.Text = row("ProductPrice")
                'FileUpload1. = row("ProductPicture")
                TextBox7.Text = row("ProductBriefDesc")
                TextBox6.Text = row("ProductFullDesc")
                If row("ProductStatus") = "Y" Then
                    RadioButtonList1.Items(0).Selected = True
                Else
                    RadioButtonList1.Items(1).Selected = True
                End If
                DropDownList1.Text = row("CategoryID")
                TextBox4.Text = row("CurrStock")
            Next
            cmd.Dispose()
            dset.Clear()
            con.Close()
        End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        Dim con As OleDb.OleDbConnection
        Dim cmd As OleDb.OleDbCommand
        con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")
        cmd = New OleDb.OleDbCommand()
        Dim s As String
        If RadioButtonList1.Items(0).Selected = True Then
            s = "Y"
        Else
            s = "N"
            cmd.CommandText = "Update ProductMaster set currStock = '" + 0 + "'"

        End If

        cmd.CommandText = "Update ProductMaster set ProductName='" + TextBox2.Text + "',ProductPrice='" + TextBox3.Text + "',ProductBriefDesc='" + TextBox7.Text + "',ProductFullDesc='" + TextBox6.Text + "',ProductStatus='" + s + "',CategoryID='" + DropDownList1.Text + "',CurrStock='" + TextBox4.Text + "' where ProductID='" + TextBox1.Text + "'"
        cmd.Connection = con
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
        ' Session("uname") = TextBox1.Text

        Server.Transfer("ViewAlterProduct.aspx")


    End Sub
End Class