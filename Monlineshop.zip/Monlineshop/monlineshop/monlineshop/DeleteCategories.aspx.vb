﻿Public Partial Class DeleteCategories
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim con As OleDb.OleDbConnection
            Dim cmd As OleDb.OleDbCommand
            con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")
            cmd = New OleDb.OleDbCommand()

            Dim s As String
            s = Request.QueryString("vcid")

            cmd.CommandText = "delete from CategoryMaster where categoryid='" + s + "'"
            cmd.Connection = con
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            ' Session("uname") = TextBox1.Text

            Server.Transfer("ViewCategories1.aspx")
        End If
    End Sub

End Class