﻿Public Partial Class ChangeCartStatusByAdmin
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Label1.Text = Request.QueryString("vcartid")
        End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        Dim con As OleDb.OleDbConnection
        Dim cmd As OleDb.OleDbCommand
        con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")
        cmd = New OleDb.OleDbCommand()
        If DropDownList1.Text = "Delivered" Then
            cmd.CommandText = "Insert into CompletedBuyNow Select * from BuyNow where cartid = '" + Label1.Text + "'"
            cmd.Connection = con
            con.Open()
            cmd.ExecuteNonQuery()
            cmd.CommandText = "UPDATE cartstatus SET Status = '" + DropDownList1.Text + "' where cartid = '" + Label1.Text + "'"
            cmd.Connection = con
            cmd.ExecuteNonQuery()
            cmd.CommandText = "Insert into CompletedCartStatus Select * from CartStatus where cartid = '" + Label1.Text + "'"
            cmd.Connection = con
            cmd.ExecuteNonQuery()
            cmd.CommandText = "delete from BuyNow where cartid = '" + Label1.Text + "'"
            cmd.Connection = con
            cmd.ExecuteNonQuery()
            cmd.CommandText = "delete from  cartstatus where cartid = '" + Label1.Text + "'"
            cmd.Connection = con
            cmd.ExecuteNonQuery()
            con.Close()
        Else
            cmd.CommandText = "UPDATE cartstatus SET Status = '" + DropDownList1.Text + "' where cartid = '" + Label1.Text + "'"
            cmd.Connection = con
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
        End If
        Server.Transfer("AdminViewCart.aspx")
    End Sub
End Class