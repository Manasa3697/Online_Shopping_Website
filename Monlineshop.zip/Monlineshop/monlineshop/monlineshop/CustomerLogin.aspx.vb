﻿Public Partial Class CustomerLogin
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        Dim con As OleDb.OleDbConnection
        Dim s As String
        con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")

        Dim dset As New DataSet()
        Dim dtab As New DataTable()
        Dim I As Integer

        I = 0
        s = "select *  from registercustomer where username='" + TextBox1.Text + "' and password='" + TextBox2.Text + "'"

        Dim cmd As New Data.OleDb.OleDbDataAdapter(s, con)
        Dim VSID As String
        VSID = ""
        con.Open()
        cmd.Fill(dset, "registercustomer")
        Response.Write("<P ALIGN=CENTER> <TABLE NOBORDER CELLPADDING=20>")
        For Each row In dset.Tables(0).Rows
            VSID = TextBox1.Text + Year(Now()).ToString + Month(Now()).ToString + Day(Now()).ToString + Hour(Now()).ToString + Minute(Now()).ToString + Second(Now()).ToString

            Session("uname") = TextBox1.Text
            Session("vsid") = VSID.ToString
            Server.Transfer("AfterCustomerlogin1.aspx")
            I = I + 1
        Next
        If I = 0 Then
            MsgBox("Invalid username or password")
        End If
    End Sub
End Class