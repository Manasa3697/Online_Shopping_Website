﻿Public Partial Class REMOVEITEMFROMCART
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim con As OleDb.OleDbConnection
            Dim cmd As OleDb.OleDbCommand
            con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")
            cmd = New OleDb.OleDbCommand()

            Dim pid, cid As String
            pid = Request.QueryString("vpid")
            cid = Request.QueryString("vcartid")
            cmd.CommandText = "delete from cart where cartid='" + cid + "' AND productid = '" + pid + "'"
            cmd.Connection = con
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()


            Server.Transfer("ShowCart.aspx")

        End If
    End Sub

End Class