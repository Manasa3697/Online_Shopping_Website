﻿Public Partial Class CustomerMaster
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        Dim con As OleDb.OleDbConnection
        Dim cmd As OleDb.OleDbCommand
        con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")
        cmd = New OleDb.OleDbCommand()


        cmd.CommandText = "Insert into CustomerMaster values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "')"
        cmd.Connection = con
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
        Session("uname") = TextBox1.Text

        TextBox1.Text = ""
        TextBox2.Text = ""

        TextBox3.Text = ""
        TextBox4.Text = ""

        TextBox5.Text = ""





    End Sub
End Class