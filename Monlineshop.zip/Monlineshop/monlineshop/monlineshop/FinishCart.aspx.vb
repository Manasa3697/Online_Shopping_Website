﻿Public Partial Class FinishCart
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label1.Text = Session("uname")
        Label2.Text = Session("vsid")
    End Sub

End Class