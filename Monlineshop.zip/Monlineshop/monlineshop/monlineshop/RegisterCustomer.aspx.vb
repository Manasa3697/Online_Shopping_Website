﻿Public Partial Class RegisterCustomer
    Inherits System.Web.UI.Page

   

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        Dim con As OleDb.OleDbConnection
        Dim cmd As OleDb.OleDbCommand
        con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")
        cmd = New OleDb.OleDbCommand()


        cmd.CommandText = "Insert into RegisterCustomer values('" + TextBox1.Text + "','" + TextBox2.Text + "')"
        cmd.Connection = con
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
        Session("uname") = TextBox1.Text

        cmd.CommandText = "Insert into Customermaster(username) values('" + TextBox1.Text + "')"
        cmd.Connection = con
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
        TextBox1.Text = ""
        TextBox2.Text = ""
        Server.Transfer("default.aspx")


    End Sub
End Class