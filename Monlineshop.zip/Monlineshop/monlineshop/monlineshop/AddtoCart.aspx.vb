﻿Public Partial Class AddtoCart
    Inherits System.Web.UI.Page
    Dim vcartid As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim vc As String
            vc = ""
            
            Label6.Text = Session("vsid")
            Label3.Text = Request.QueryString("vpid")
            Dim con As OleDb.OleDbConnection
            Dim s As String
            con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")

            Dim dset As New DataSet()
            Dim dtab As New DataTable()
            Dim I As Integer

            I = 0
            s = "select *  from productMaster where Productid='" + Label3.Text + "'"

            Dim cmd As New Data.OleDb.OleDbDataAdapter(s, con)

            con.Open()
            cmd.Fill(dset, "xyz")

            For Each row In dset.Tables(0).Rows
                Label1.Text = row("ProductName")
                Label4.Text = row("ProductPrice")
                If row("ProductStatus") = "Y" Then
                    Label5.Text = row("CurrStock")
                Else
                    Label5.Text = 0
                End If

            Next
            cmd.Dispose()
            dset.Clear()
            con.Close()
        End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        Dim con As OleDb.OleDbConnection
        Dim cmd As OleDb.OleDbCommand
        con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")
        cmd = New OleDb.OleDbCommand()
       
        cmd.CommandText = "Insert into Cart values('" + Label6.Text + "','" + Label3.Text + "','" + TextBox1.Text + "')"
        cmd.Connection = con
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
        Server.Transfer("AFTERCUSTOMERLOGIN1.ASPX")

        
    End Sub

   
End Class