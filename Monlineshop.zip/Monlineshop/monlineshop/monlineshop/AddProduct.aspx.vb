﻿Public Partial Class AddProduct
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim con As OleDb.OleDbConnection
        Dim s As String
        con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")

        Dim dset As New DataSet()
        Dim dtab As New DataTable()
        Dim I As Integer

        I = 0
        s = "select categoryid  from categorymaster"

        Dim cmd As New Data.OleDb.OleDbDataAdapter(s, con)

        con.Open()
        cmd.Fill(dset, "xyz")

        For Each row In dset.Tables(0).Rows
            DropDownList1.Items.Add(row("categoryid"))
        Next
        cmd.Dispose()
        dset.Clear()
        con.Close()

    End Sub

    Protected Sub TextBox3_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        Dim con As OleDb.OleDbConnection
        Dim cmd As OleDb.OleDbCommand
        con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")
        cmd = New OleDb.OleDbCommand()
        Dim s As String

        If RadioButtonList1.Items(0).Selected = True Then
            s = "Y"
        Else
            s = "N"
        End If

        cmd.CommandText = "Insert into ProductMaster values('" + TextBox1.Text + "','" + TextBox2.Text + "'," + TextBox3.Text + ",'" + FileUpload1.FileName + "','" + TextBox7.Text + "','" + TextBox6.Text + "','" + s + "','" + DropDownList1.Text + "','" + TextBox4.Text + "')"
        cmd.Connection = con
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
        ' Session("uname") = TextBox1.Text

        TextBox1.Text = ""
        TextBox2.Text = ""

        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox7.Text = ""
        TextBox6.Text = ""

           End Sub

    Protected Sub RadioButtonList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles RadioButtonList1.SelectedIndexChanged

        If RadioButtonList1.Items(1).Selected = True Then
            TextBox4.Text = 0
            TextBox4.Enabled = False
        End If
    End Sub
End Class