﻿Public Partial Class AlterCategories
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            TextBox1.Text = Request.QueryString("vcid")
            Dim con As OleDb.OleDbConnection
            Dim s As String
            con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")

            Dim dset As New DataSet()
            Dim dtab As New DataTable()
            Dim I As Integer

            I = 0
            s = "select *  from categorymaster where categoryid='" + TextBox1.Text + "'"

            Dim cmd As New Data.OleDb.OleDbDataAdapter(s, con)

            con.Open()
            cmd.Fill(dset, "xyz")

            For Each row In dset.Tables(0).Rows
                TextBox2.Text = row("maincategory")
                TextBox3.Text = row("subcategory1")
                TextBox4.Text = row("subcategory2")
                TextBox5.Text = row("subcategory3")
            Next
            cmd.Dispose()
            dset.Clear()
            con.Close()
        End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        Dim con As OleDb.OleDbConnection
        Dim cmd As OleDb.OleDbCommand
        con = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\monlineshop\monlineshop.accdb")
        cmd = New OleDb.OleDbCommand()
       
        cmd.CommandText = "Update CategoryMaster set mainCategory='" + TextBox2.Text + "',subcategory1='" + TextBox3.Text + "',subcategory2='" + TextBox4.Text + "',subcategory3='" + TextBox5.Text + "' where categoryID='" + TextBox1.Text + "'"
        cmd.Connection = con
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
        ' Session("uname") = TextBox1.Text

        Server.Transfer("ViewCategories.aspx")


    End Sub
End Class